import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

/*
In index.js file:
Create the Root Object.
The static student page needs to contain:
Your full name as <h1> tag,
Use your preferred name, if different.
Hyperlink to your email.

Your favorite color.
Change the background color of this element only to your favorite color.
Ensure font color is easily readable.
Hyperlink to your favorite website.
Image of your favorite activity.
Stackblitz only supports remote images. If you would like to use your own image, upload it to GitHub first, then use the GitHub link as your source on StackBlitz.
List of classes you are enrolled in this semester.
In addition, ensure that:
At least one (1) element has an ID,
At least one (1) element has a class.

*/

root.render(
  <React.StrictMode>
    <div>
      <h1>Finnegan (Finn) Walker</h1>
      <a href="mailto:frwalker@us.edu">Email Me</a>
      <p id="fav-color">Favorite color: Green</p>

      <p>
        My Favorite website:
        <a href="https://www.youtube.com/" target="_blank">
          Youtube
        </a>
      </p>

      <div className="favorite-activity">
        <img
          /*
          Image of your favorite activity.
          Stackblitz only supports remote images. If you would like to use your own image, upload it to GitHub first, then use the GitHub link as your source on StackBlitz.

          -- make sure -- 

          In addition, ensure that:
          At least one (1) element has an ID,
          At least one (1) element has a class.


        */
          src="https://sbisoccer.com/wp-content/uploads/USMNT-Mexico-2-e1687744951124-1200x673.jpg"
          alt="USMT Soccer Team"
        />
        <p>Favorite activity: Watching USMNT</p>
      </div>

      <ul className="class-list">
        <p>My Fall 2023 Classes</p>
        <li>ITP 301: Front-End Web Development</li>
        <li>ECON 352: Macroeconomics for Business</li>
        <li>BUAD 308: Advanced Business Finance</li>
        <li>ITP 342: AiOS App Development</li>
      </ul>
    </div>
  </React.StrictMode>
);
