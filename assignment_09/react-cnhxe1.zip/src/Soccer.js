import React from 'react';

const Soccer = (props) => {
  const { title, director, imageUrl } = props;

  return (
    <div className="conmedia">
      <img src={imageUrl} alt={title} />
      <h2>{title}</h2>
      <p>Coach: {director}</p>
    </div>
  );
};

export default Soccer;
