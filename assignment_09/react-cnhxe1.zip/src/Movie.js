import React from 'react';

const Movie = (props) => {
  const { title, director, imageUrl } = props;

  return (
    <div className="conmedia">
      <img src={imageUrl} alt={title} />
      <h2>{title}</h2>
      <p>Director: {director}</p>
    </div>
  );
};

export default Movie;
