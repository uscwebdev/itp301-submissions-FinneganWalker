import React, { useState } from 'react';
// import ReactDOM from 'react-dom';
// was going to use but got an error saying that it was unsupported
import './index.css';
import './propCSS.css';
import { createRoot } from 'react-dom/client';
import Popup from './Popup';
import Movie from './Movie';
import TV from './TV';
import Soccer from './Soccer';

const App = () => {
  const [showPopup, setShowPopup] = useState(false);

  const profilePicURL = 'https://shorturl.at/bdsJL';
  const emailAddress = 'example@example.com';
  const phoneNumber = '123-456-7890';
  const instagramUsername = 'your_username';

  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  return (
    <React.StrictMode>
      <div id="navBarTotal">
        <div id="navBarLeft">
          {/*Profile Icon*/}
          <img src={profilePicURL} alt="ProfilePicture" />
        </div>

        <div id="navBarCenter">
          {/*Title*/}
          <h1>Get To Know Me</h1>
        </div>

        <div id="navBarRight">
          {/*BookMark, Link1,2,3 --> Different Divs*/}
          <div id="bookmark">
            <p>
              <button onClick={togglePopup}>Bookmark</button>
              {showPopup && <Popup onClose={togglePopup} />}
            </p>
          </div>
          <div className="linkButton">
            <p>
              <a href="#movies">Movies</a>
            </p>
          </div>
          <div className="linkButton">
            <p>
              <a href="#tv">TV</a>
            </p>
          </div>
          <div className="linkButton">
            <p>
              <a href="#soccer">Soccer</a>
            </p>
          </div>
        </div>
      </div>

      {/* PERSONAL SECTION */}
      <div id="personalSection">
        <div id="description">
          <h3>Personal Description</h3>
          <p>
            Hey, my name is Finnegan Walker and this is my website. The purpose
            of this website is to get to know me a little more. Get to
            understand some of my hobbies, tv shows, movies, soccer teams, and I
            may be adding sections on music and other hobbies of mine. To
            navigate the website, you have the three buttons up top marked
            “Movies”, “TV”, and “Soccer”. Each of these buttons will take you to
            their respective area on the single page website. Also what is going
            to be added in the coming weeks is a bookmark tab. Right now the
            button you see at the top is just a placeholder with a popup
            function. When fully incorporated, it will act as a placeholder for
            all of the movies, tv shows or anything else that you want to
            bookmark and come back to. You will be able to add anything you see
            below to the bookmark and treat it like a shopping cart of hobbies.
            Have fun and enjoy the website.
          </p>
        </div>
        <div id="contactInfo">
          <h3>Contact Info</h3>
          <p>
            Email: <a href={`mailto:${emailAddress}`}>{emailAddress}</a>
          </p>
          <p>
            Phone: <a href={`tel:${phoneNumber}`}>{phoneNumber}</a>
          </p>
          <p>
            Follow me on Instagram:{' '}
            <a
              href={`https://www.instagram.com/${instagramUsername}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              @{instagramUsername}
            </a>
          </p>
        </div>
      </div>

      <div id="mainSection">
        <div>
          <h3>Movies I like:</h3>
        </div>
        <div id="movies">
          <Movie
            title="Spider Man Across The Spider Verse"
            director="joaquim dos santos"
            imageUrl="https://m.media-amazon.com/images/I/919p74MDUEL._AC_UF1000,1000_QL80_.jpg"
          />
          <Movie
            title="The Dark Knight"
            director="Christopher Nolan"
            imageUrl="https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg"
          />
          <Movie
            title="Inception"
            director="Christopher Nolan"
            imageUrl="https://m.media-amazon.com/images/M/MV5BMTM0MjUzNjkwMl5BMl5BanBnXkFtZTcwNjY0OTk1Mw@@._V1_.jpg"
          />
          <Movie
            title="Tenet"
            director="Christopher Nolan"
            imageUrl="https://m.media-amazon.com/images/M/MV5BOTU4ZmNmMTktYzRkYS00Njc1LTg3ZjQtNDY4MmM0MTE5ZjhmXkEyXkFqcGdeQXVyMTA3MDk2NDg2._V1_.jpg"
          />
          <Movie
            title="13 Hours"
            director="Michael Bay"
            imageUrl="https://m.media-amazon.com/images/I/91zhWpXHVzL._AC_UF1000,1000_QL80_.jpg"
          />
        </div>
        <div>
          <h3>Shows I like:</h3>
        </div>
        <div id="tv">
          <TV
            title="Breaking Bad"
            director="Vince Gilligan"
            imageUrl="https://shorturl.at/jwEO9"
          />
          <TV
            title="Game of Thrones"
            director="David Benioff"
            imageUrl="https://shorturl.at/wzQX8"
          />
          <TV
            title="Invincible"
            director="Robert Kirkman"
            imageUrl="https://shorturl.at/vBR17"
          />
          <TV
            title="The Witcher"
            director="Marc Jobst"
            imageUrl="https://hips.hearstapps.com/hmg-prod/images/thewitcher-igstory-poster20190701-6015-sskkxu-1561998794.jpeg?crop=1.00xw:0.564xh;0.00170xw,0.0709xh&resize=640:*"
          />
          <TV
            title="Jack Ryan"
            director="Carlton Cuse"
            imageUrl="https://resizing.flixster.com/PJLczB3-TfyOMV3qm5JW6qOi2BM=/ems.cHJkLWVtcy1hc3NldHMvdHZzZWFzb24vUlRUVjU1NjU3OS53ZWJw"
          />
        </div>
        <div>
          <h3>Soccer Teams I like:</h3>
        </div>
        <div id="soccer">
          <Soccer
            title="AC Milan"
            director="Stefano Pioli"
            imageUrl="https://cdn.freebiesupply.com/images/thumbs/2x/ac-milan-logo.png"
          />
          <Soccer
            title="Chelsea"
            director="Mauricio Pochettino"
            imageUrl="https://upload.wikimedia.org/wikipedia/en/thumb/c/cc/Chelsea_FC.svg/1200px-Chelsea_FC.svg.png"
          />
          <Soccer
            title="USMNT"
            director="Gregg Berhalter"
            imageUrl="https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/United_States_Soccer_Federation_logo_2016.svg/1495px-United_States_Soccer_Federation_logo_2016.svg.png"
          />
          <Soccer
            title="Spurs"
            director="Ange Postecoglou"
            imageUrl="https://upload.wikimedia.org/wikipedia/hif/6/6d/Tottenham_Hotspur.png"
          />
          <Soccer
            title="Real Madrid"
            director="Carlo Ancelotti"
            imageUrl="https://seeklogo.com/images/R/Real_Madrid_Club_de_Futbol-logo-60682932F8-seeklogo.com.png"
          />
        </div>
        <div id="footer">
          <p>
            <a
              href={`mailto:${emailAddress}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              Contact Me
            </a>
          </p>
        </div>
      </div>
    </React.StrictMode>
  );
};

const root = createRoot(document.querySelector('#root'));
root.render(<App />);
