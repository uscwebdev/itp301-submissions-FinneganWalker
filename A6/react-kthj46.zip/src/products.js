import React from 'react';

export default function Art(prop) {
  return (
    <div id="product">
      <div className="IMG-div">
        <img className="IMG" src={prop.src} alt={prop.alt} />
      </div>

      <p>
        <strong>{prop.artist}</strong>
      </p>

      <p>{prop.paintName}</p>

      <p>${prop.p}</p>
    </div>
  );
}
