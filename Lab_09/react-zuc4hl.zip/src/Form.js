import React, { useState } from 'react';

export default function Form() {
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [charCount, setCharCount] = useState(0);

  const [errors, setErrors] = useState({
    fullName: '',
    password: '',
    passwordConfirm: '',
    email: '',
    phone: '',
    comment: '',
    acceptTerms: '',
  });

  const handleInputChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    switch (name) {
      case 'full-name':
        setFullName(value);
        break;
      case 'password':
        setPassword(value);
        break;
      case 'password-confirm':
        setPasswordConfirm(value);
        break;
      case 'email':
        setEmail(value);
        break;
      case 'phone':
        setPhone(value);
        break;
      case 'comment':
        setComment(value);
        setCharCount(value.length);
        break;
      case 'terms':
        setAcceptTerms(!acceptTerms);
        break;
      default:
        break;
    }
  };

  const validateForm = () => {
    const newErrors = {
      fullName: '',
      password: '',
      passwordConfirm: '',
      email: '',
      phone: '',
      comment: '',
      acceptTerms: '',
    };

    let isValid = true;

    if (fullName.trim() === '') {
      newErrors.fullName = 'Name cannot be empty.';
      isValid = false;
    } else if (!fullName.includes(' ')) {
      newErrors.fullName = 'You must provide a full name.';
      isValid = false;
    }

    if (password === '') {
      newErrors.password = 'Password cannot be empty.';
      isValid = false;
    } else if (password.length < 5) {
      newErrors.password = 'Password must contain at least 5 characters.';
      isValid = false;
    } else if (!/[A-Z]/.test(password) || !/[a-z]/.test(password)) {
      newErrors.password =
        'Password must contain uppercase and lowercase characters.';
      isValid = false;
    }

    if (passwordConfirm !== password) {
      newErrors.passwordConfirm = 'Passwords do not match.';
      isValid = false;
    }

    if (email.trim() === '' && phone.trim() === '') {
      newErrors.email = 'You must provide either email or phone.';
      newErrors.phone = 'You must provide either email or phone.';
      isValid = false;
    }

    if (comment.length > 100) {
      newErrors.comment = 'Comments cannot exceed 100 characters.';
      isValid = false;
    }

    if (!acceptTerms) {
      newErrors.acceptTerms = 'You must accept Terms & Conditions.';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      alert('Registration Successful');
    } else {
      let errorMessages = '';
      for (const field in errors) {
        if (errors[field]) {
          errorMessages += `${errors[field]}\n`;
        }
      }
      alert(errorMessages);
    }
  };

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  name="full-name"
                  value={fullName}
                  onChange={handleInputChange}
                />
                <span className="text-danger">{errors.fullName}</span>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  value={password}
                  onChange={handleInputChange}
                />
                <span className="text-danger">{errors.password}</span>
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  name="password-confirm"
                  value={passwordConfirm}
                  onChange={handleInputChange}
                />
                <span className="text-danger">{errors.passwordConfirm}</span>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      name="email"
                      value={email}
                      onChange={handleInputChange}
                    />
                    <span className="text-danger">{errors.email}</span>
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      name="phone"
                      value={phone}
                      onChange={handleInputChange}
                    />
                    <span className="text-danger">{errors.phone}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  name="comment"
                  value={comment}
                  onChange={handleInputChange}
                ></textarea>
                <small id="comment-count" className="form-text text-right">
                  {charCount} / 100
                </small>
                <span className="text-danger">{errors.comment}</span>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    name="terms"
                    checked={acceptTerms}
                    onChange={handleInputChange}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
                <span className="text-danger">{errors.acceptTerms}</span>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
