import React from 'react';

const Movie = ({
  title,
  director,
  imageUrl,
  onMoreInfoClick,
  onRemoveClick,
}) => {
  return (
    <div className="conmedia">
      <img src={imageUrl} alt={title} />
      <h2>{title}</h2>
      <p>Director: {director}</p>
      <button onClick={() => onMoreInfoClick(title)}>Trailer</button>
      <button onClick={() => onRemoveClick(title)}>Remove</button>
    </div>
  );
};

export default Movie;
