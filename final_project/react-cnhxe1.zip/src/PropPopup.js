import React from 'react';
import './Popup.css';

const ContentPop = ({ onClose, title, trailerUrl }) => {
  return (
    <div className="popup">
      <div className="popup-inner">
        <button className="close-btn" onClick={onClose}>
          Close
        </button>
        <h2>{title}</h2>
        <iframe
          src={trailerUrl}
          title="Trailer"
          width="560"
          height="315"
        ></iframe>
      </div>
    </div>
  );
};

export default ContentPop;
