import React from 'react';

const Soccer = ({ title, director, imageUrl, onMoreInfoClick }) => {
  return (
    <div className="conmedia">
      <img src={imageUrl} alt={title} />
      <h2>{title}</h2>
      <p>Coach: {director}</p>
      <button onClick={() => onMoreInfoClick(title)}>Highlights</button>
    </div>
  );
};

export default Soccer;
