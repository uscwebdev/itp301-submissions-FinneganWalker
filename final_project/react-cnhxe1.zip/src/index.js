import React, { useState, useEffect } from 'react';
// import ReactDOM from 'react-dom';
// was going to use but got an error saying that it was unsupported
import './index.css';
import { createRoot } from 'react-dom/client';
import Popup from './Popup';
import Movie from './Movie';
import TV from './TV';
import Soccer from './Soccer';
import ContentPop from './PropPopup';

// COULD NOT ADD ALL IMAGES TO img folder DUE TO LIMIT on stackblitz...
// IMG's are included in the folder when submitted

const App = () => {
  // State for controlling the visibility of the generic Popup
  const [showPopup, setShowPopup] = useState(false);
  // State for controlling the visibility of the ContentPop
  const [showContentPop, setShowContentPop] = useState(false);
  // State for holding the selected content for ContentPop
  const [selectedContent, setSelectedContent] = useState(null);

  // for add movie
  const [newMovieData, setNewMovieData] = useState({
    title: '',
    director: '',
    imageUrl: '',
    trailerUrl: '',
  });
  const [showAddMoviePopup, setShowAddMoviePopup] = useState(false);

  const handleAddMovieInputChange = (e) => {
    setNewMovieData({ ...newMovieData, [e.target.name]: e.target.value });
  };

  const handleAddMovie = (e) => {
    e.preventDefault();
    addMovie(newMovieData);
    setShowAddMoviePopup(false);
    setNewMovieData({ title: '', director: '', imageUrl: '', trailerUrl: '' });
  };

  // other variables
  const profilePicURL = 'https://shorturl.at/bdsJL';
  const emailAddress = 'frwalker@usc.com';
  const phoneNumber = '(805) 895-7747';
  const instagramUsername = 'finnrwalker';

  const addMovie = (newMovie) => {
    setMovies([...movies, newMovie]);
  };

  const removeMovie = (movieTitle) => {
    setMovies(movies.filter((movie) => movie.title !== movieTitle));
  };

  const initialMovies = [
    // trailer implementation coming soon
    {
      title: 'Spider Man Across The Spider Verse',
      director: 'Joaquim Dos Santos',
      imageUrl:
        'https://m.media-amazon.com/images/I/8105Oc1+FPL._AC_UF894,1000_QL80_.jpg',
      trailerUrl: 'https://www.youtube.com/watch?v=shW9i6k8cB0',
    },
    {
      title: 'The Dark Knight',
      director: 'Christopher Nolan',
      imageUrl:
        'https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg',
      trailerUrl: 'https://www.youtube.com/embed/EXeTwQWrcwY',
    },
    {
      title: 'Inception',
      director: 'Christopher Nolan',
      imageUrl:
        'https://m.media-amazon.com/images/M/MV5BMTM0MjUzNjkwMl5BMl5BanBnXkFtZTcwNjY0OTk1Mw@@._V1_.jpg',
      trailerUrl: 'https://www.youtube.com/watch?v=YoHD9XEInc0',
    },
    {
      title: 'Tenet',
      director: 'Christopher Nolan',
      imageUrl:
        'https://m.media-amazon.com/images/M/MV5BOTU4ZmNmMTktYzRkYS00Njc1LTg3ZjQtNDY4MmM0MTE5ZjhmXkEyXkFqcGdeQXVyMTA3MDk2NDg2._V1_.jpg',
      trailerUrl: 'https://www.youtube.com/watch?v=L3pk_TBkihU',
    },
    {
      title: '13 Hours',
      director: 'Michael Bay',
      imageUrl:
        'https://m.media-amazon.com/images/I/91zhWpXHVzL._AC_UF1000,1000_QL80_.jpg',
      trailerUrl: 'https://www.youtube.com/watch?v=4CJBuUwd0Os',
    },
  ];
  const tvShows = [
    // trailer implementation coming soon
    {
      title: 'Breaking Bad',
      director: 'Vince Gilligan',
      imageUrl: 'https://shorturl.at/jwEO9',
      trailerUrl: 'https://www.youtube.com/watch?v=VFLkMDEO-Xc',
    },
    {
      title: 'Game of Thrones',
      director: 'David Benioff',
      imageUrl: 'https://shorturl.at/wzQX8',
      trailerUrl: 'https://www.youtube.com/watch?v=J7JYw5kQg_Y',
    },
    {
      title: 'Invincible',
      director: 'Robert Kirkman',
      imageUrl: 'https://shorturl.at/vBR17',
      trailerUrl: 'https://www.youtube.com/watch?v=9CdykRxgmH0',
    },
    {
      title: 'The Witcher',
      director: 'Marc Jobst',
      imageUrl:
        'https://hips.hearstapps.com/hmg-prod/images/thewitcher-igstory-poster20190701-6015-sskkxu-1561998794.jpeg?crop=1.00xw:0.564xh;0.00170xw,0.0709xh&resize=640:*', // Replace with actual image URL
      trailerUrl: 'https://www.youtube.com/watch?v=ndl1W4ltcmg', // Replace with actual trailer URL
    },
    {
      title: 'Jack Ryan',
      director: 'Carlton Cuse',
      imageUrl:
        'https://resizing.flixster.com/PJLczB3-TfyOMV3qm5JW6qOi2BM=/ems.cHJkLWVtcy1hc3NldHMvdHZzZWFzb24vUlRUVjU1NjU3OS53ZWJw', // Replace with actual image URL
      trailerUrl: 'https://www.youtube.com/watch?v=1KsyZF590NM', // Replace with actual trailer URL
    },
  ];

  const [movies, setMovies] = useState(initialMovies);
  // Reset function
  const resetMovies = () => {
    setMovies(initialMovies);
    localStorage.removeItem('movies'); // Clear local storage
  };

  const soccerTeams = [
    {
      title: 'AC Milan',
      director: 'Stefano Pioli',
      imageUrl:
        'https://cdn.freebiesupply.com/images/thumbs/2x/ac-milan-logo.png',
      trailerUrl: 'https://youtube.com/embed/trailerUrlForACMilan', // Replace with actual trailer URL
    },
    {
      title: 'Chelsea',
      director: 'Mauricio Pochettino',
      imageUrl:
        'https://upload.wikimedia.org/wikipedia/en/thumb/c/cc/Chelsea_FC.svg/1200px-Chelsea_FC.svg.png',
      trailerUrl: 'https://youtube.com/embed/trailerUrlForChelsea', // Replace with actual trailer URL
    },
    {
      title: 'USMNT',
      director: 'Gregg Berhalter',
      imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/United_States_Soccer_Federation_logo_2016.svg/1495px-United_States_Soccer_Federation_logo_2016.svg.png',
      trailerUrl: 'https://youtube.com/embed/trailerUrlForUSMNT', // Replace with actual trailer URL
    },
    {
      title: 'Spurs',
      director: 'Ange Postecoglou',
      imageUrl:
        'https://upload.wikimedia.org/wikipedia/hif/6/6d/Tottenham_Hotspur.png',
      trailerUrl: 'https://youtube.com/embed/trailerUrlForSpurs', // Replace with actual trailer URL
    },
    {
      title: 'Real Madrid',
      director: 'Carlo Ancelotti',
      imageUrl:
        'https://seeklogo.com/images/R/Real_Madrid_Club_de_Futbol-logo-60682932F8-seeklogo.com.png',
      trailerUrl: 'https://youtube.com/embed/trailerUrlForRealMadrid', // Replace with actual trailer URL
    },
  ];

  // Function to toggle the generic Popup and ensure ContentPop is closed
  const togglePopup = () => {
    setShowPopup(!showPopup);
    if (showContentPop) setShowContentPop(false);
  };

  // Function to handle opening of ContentPop and ensure the generic Popup is closed
  const handleMoreInfoClick = (content) => {
    setSelectedContent(content);
    setShowContentPop(true);
    if (showPopup) setShowPopup(false);
  };

  // save locally
  useEffect(() => {
    const savedMovies = localStorage.getItem('movies');
    if (savedMovies) {
      setMovies(JSON.parse(savedMovies));
    }
  }, []);

  // Function to save movies to Local Storage whenever the movies state changes
  useEffect(() => {
    localStorage.setItem('movies', JSON.stringify(movies));
  }, [movies]);

  return (
    <React.StrictMode>
      <div id="navBarTotal">
        <div id="navBarLeft">
          {/*Profile Icon*/}
          <img src={profilePicURL} alt="ProfilePicture" />
        </div>

        <div id="navBarCenter">
          {/*Title*/}
          <h1>Get To Know Me</h1>
        </div>

        <div id="navBarRight">
          {/*BookMark, Link1,2,3 --> Different Divs*/}
          <div id="bookmark">
            <p>
              <button onClick={togglePopup}>Bookmark</button>
              {showPopup && <Popup onClose={togglePopup} />}
            </p>
          </div>
          <div className="linkButton">
            <p>
              <a href="#movies">Movies</a>
            </p>
          </div>
          <div className="linkButton">
            <p>
              <a href="#tv">TV</a>
            </p>
          </div>
          <div className="linkButton">
            <p>
              <a href="#soccer">Soccer</a>
            </p>
          </div>
        </div>
      </div>

      {/* PERSONAL SECTION */}
      <div id="personalSection">
        <div id="description">
          <h3>Personal Description</h3>
          <p>
            Hey, my name is Finnegan Walker and this is my website. The purpose
            of this website is to get to know me a little more. Get to
            understand some of my hobbies, tv shows, movies, soccer teams, and I
            may be adding sections on music and other hobbies of mine. To
            navigate the website, you have the three buttons up top marked
            “Movies”, “TV”, and “Soccer”. Each of these buttons will take you to
            their respective area on the single page website. Also what is going
            to be added in the coming weeks is a bookmark tab. Right now the
            button you see at the top is just a placeholder with a popup
            function. When fully incorporated, it will act as a placeholder for
            all of the movies, tv shows or anything else that you want to
            bookmark and come back to. You will be able to add anything you see
            below to the bookmark and treat it like a shopping cart of hobbies.
            Have fun and enjoy the website. Also, any recommendations are
            welcome!
          </p>
        </div>
        <div id="contactInfo">
          <h3>Contact Info</h3>
          <p>
            Email: <a href={`mailto:${emailAddress}`}>{emailAddress}</a>
          </p>
          <p>
            Phone: <a href={`tel:${phoneNumber}`}>{phoneNumber}</a>
          </p>
          <p>
            Follow me on Instagram:{' '}
            <a
              href={`https://www.instagram.com/${instagramUsername}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              @{instagramUsername}
            </a>
          </p>
        </div>
      </div>

      <div id="mainSection">
        <div id="movies-section">
          <h1>Movies I like:</h1>
          {/* Example buttons for adding/removing a movie (you can create a form or other UI components) */}
          {/* Button to show add movie form */}
          <button
            className="add-movie-btn"
            onClick={() => setShowAddMoviePopup(true)}
          >
            Add Your Movie
          </button>
          {/* Reset Button */}
          <button className="reset-movies-btn" onClick={resetMovies}>
            Reset Movies List
          </button>
          {/* Add Movie Popup */}
          {showAddMoviePopup && (
            <div className="popup">
              <div className="popup-inner">
                <form onSubmit={handleAddMovie}>
                  <label>Title:</label>
                  <input
                    type="text"
                    name="title"
                    value={newMovieData.title}
                    onChange={handleAddMovieInputChange}
                    required
                  />
                  <label>Director:</label>
                  <input
                    type="text"
                    name="director"
                    value={newMovieData.director}
                    onChange={handleAddMovieInputChange}
                    required
                  />
                  <label>Image URL:</label>
                  <input
                    type="text"
                    name="imageUrl"
                    value={newMovieData.imageUrl}
                    onChange={handleAddMovieInputChange}
                    required
                  />
                  <label>Trailer URL:</label>
                  <input
                    type="text"
                    name="trailerUrl"
                    value={newMovieData.trailerUrl}
                    onChange={handleAddMovieInputChange}
                    required
                  />
                  <button type="submit">Add Movie</button>
                </form>
                <button
                  id="addbutton"
                  onClick={() => setShowAddMoviePopup(false)}
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
        {/* Movies Section */}
        <div id="movies">
          {movies.map((movie, index) => (
            <Movie
              key={index}
              title={movie.title}
              director={movie.director}
              imageUrl={movie.imageUrl}
              onMoreInfoClick={() => handleMoreInfoClick(movie)}
              onRemoveClick={removeMovie}
            />
          ))}
        </div>

        <div>
          <h1>Shows I like:</h1>
        </div>
        {/* TV Shows Section */}
        <div id="tv">
          {tvShows.map((show) => (
            <TV
              key={show.title}
              title={show.title}
              director={show.director}
              imageUrl={show.imageUrl}
              trailerUrl={show.trailerUrl}
              onMoreInfoClick={() => handleMoreInfoClick(show)}
            />
          ))}
        </div>

        {/* Soccer Teams Section */}
        <div id="soccer">
          {soccerTeams.map((team) => (
            <Soccer
              key={team.title}
              title={team.title}
              director={team.director}
              imageUrl={team.imageUrl}
              trailerUrl={team.trailerUrl}
              onMoreInfoClick={() => handleMoreInfoClick(team)}
            />
          ))}
        </div>

        <div id="footer">
          <p>
            {' '}
            This website is owned and opporated by @FinnIncorporated - if you
            have any questions, please -
            <a
              href={`mailto:${emailAddress}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              Contact Me
            </a>
          </p>
        </div>
      </div>

      {/* Bookmark Popup */}
      {showPopup && <Popup onClose={togglePopup} />}

      {/* ContentPop for Movies, TV Shows, and Soccer Teams */}
      {showContentPop && selectedContent && (
        <ContentPop
          onClose={() => setShowContentPop(false)}
          title={selectedContent.title}
          trailerUrl={selectedContent.trailerUrl}
        />
      )}
    </React.StrictMode>
  );
};

const root = createRoot(document.querySelector('#root'));
root.render(<App />);
