import React from 'react';
import './Popup.css';

const Popup = ({ onClose }) => {
  return (
    <div className="popup">
      <div className="popup-inner">
        <button className="close-btn" onClick={onClose}>
          Close
        </button>
        <h2>Bookmark Page (for future)</h2>
        <p>
          "Comming Soon" Page to add bookmarable ideas once I add more content!
        </p>
      </div>
    </div>
  );
};

export default Popup;
