import React from 'react';

const TV = ({ title, director, imageUrl, onMoreInfoClick }) => {
  return (
    <div className="conmedia">
      <img src={imageUrl} alt={title} />
      <h2>{title}</h2>
      <p>Director: {director}</p>
      <button onClick={() => onMoreInfoClick(title)}>Trailer</button>
    </div>
  );
};

export default TV;
