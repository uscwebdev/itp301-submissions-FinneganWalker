import React, { useState } from 'react';
import './index.css';
import { createRoot } from 'react-dom/client';

// remember to import css
/*
Create and display the default image and caption for that image.
Include all required image attributes (src and alt).
Create an event handler function that:
Accepts three (3) parameters:
New src value,
New alt value,
New caption value.
Updates state variables to values passed as parameters.
When users click on a button, invoke the event handler created above and pass in all parameter values. You can just hard-code these values.
The event handler will simply update state variables to these new values, which in turn will re-render and display the new image and caption.

CHECK LIST
- 5 images / buttons --> DONE
- New alt / src / caption --> DONE
- CSS --> DONE
*/

const root = createRoot(document.querySelector('#root'));

function App() {
  const [imageUrl, setImageUrl] = useState(
    'https://phantom-marca.unidadeditorial.es/f96a0f2e89a59fa9905e5e2d4cdd629a/crop/0x0/2041x1361/resize/828/f/jpg/assets/multimedia/imagenes/2023/10/06/16965870244978.jpg'
  );

  // sets the original image alt and caption to Messi and Lionel Messi
  // Every time you refresh then it resets to original stuff
  const [imageAlt, setImageAlt] = useState('Messi');
  const [caption, setCaption] = useState('Lionel Messi');

  // change image variable to get each factor of the image... ie, url, alt and caption
  const changeImage = (newSrc, newAlt, newCaption) => {
    setImageUrl(newSrc);
    setImageAlt(newAlt);
    setCaption(newCaption);
  };

  // label = button
  // src = image url
  // alt = image alt
  // caption = "name" --> what it says below image -> format in css

  const imageButtons = [
    {
      label: 'Image 1',
      src: 'https://phantom-marca.unidadeditorial.es/f96a0f2e89a59fa9905e5e2d4cdd629a/crop/0x0/2041x1361/resize/828/f/jpg/assets/multimedia/imagenes/2023/10/06/16965870244978.jpg',
      alt: 'Messi',
      caption: 'Lionel Messi',
    },
    {
      label: 'Image 2',
      src: 'https://media.cnn.com/api/v1/images/stellar/prod/230621042149-01-cristiano-ronaldo-euro-200-apps-062023-restricted.jpg?c=16x9&q=h_720,w_1280,c_fill',
      alt: 'Ronaldo',
      caption: 'Cristiano Ronaldo',
    },
    {
      label: 'Image 3',
      src: 'https://cdn.britannica.com/21/92821-050-7CFB7CC2/David-Beckham-2005.jpg',
      alt: 'Beckham',
      caption: 'David Beckham',
    },
    {
      label: 'Image 4',
      src: 'https://cdn.britannica.com/76/124976-050-E03E50CE/Diego-Maradona-1986.jpg',
      alt: 'Maradona',
      caption: 'Diego Maradona',
    },
    {
      label: 'Image 5',
      src: 'https://library.sportingnews.com/2023-04/Christian%20Pulisic%20Chelsea%20Super%20Cup%20action%20081221.jpg',
      alt: 'Pulisic',
      caption: 'Christian Pulisic',
    },
  ];

  return (
    <React.StrictMode>
      <div className="App">
        <div id="main">
          <div id="titletext">
            <h1>Lab 7 - Photo Gallery</h1>
          </div>
          <h3>WHO IS THE GOAT</h3>
          {imageButtons.map((button, index) => (
            <button
              key={index}
              onClick={() =>
                changeImage(button.src, button.alt, button.caption)
              }
            >
              {button.label}
            </button>
          ))}
          <div id="IMG">
            <img src={imageUrl} alt={imageAlt} className="gallery-image" />
            <p className="caption">{caption}</p>
          </div>
        </div>
      </div>
    </React.StrictMode>
  );
}

root.render(<App />);

export default App;
