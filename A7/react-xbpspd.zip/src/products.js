import React from 'react';
import { useState } from 'react';

export default function Art(prop) {
  /*

For each product, add:
A button that displays – (minus sign),
A button that displays + (plus sign),
A counter in between the buttons (initialized to 0).
Implement the –/+ button functionalities:
When users click on the + button, increment the count only for that product by 1 each time.


Hints:
Since the count has to be re-rendered upon change, you will need to use a state variable within the product component to display the count.
A single component can have multiple elements that detect click events. To distinguish between both events, you can call the event handlers "handleMinusClick" and "handlePlusClick."



Also To-DO:
Button display --> -
Button display --> +
Button Counter --> 0 then add to it using variable "count"

use handleMinusClick and handlePlusClick
 - plus clicks -> count + 1
 - minus clicks -> count - 1 


*/

  const [count, setCount] = useState(0);

  const handleMinusClick = () => {
    if (count > 0) {
      setCount(count - 1);
    }
  };

  const handlePlusClick = () => {
    setCount(count + 1);
  };

  return (
    <div id="product">
      <div className="IMG-div">
        <img className="IMG" src={prop.src} alt={prop.alt} />
      </div>

      <p>
        <strong>{prop.artist}</strong>
      </p>

      <p>{prop.paintName}</p>

      <p>${prop.p}</p>

      <div className="plus-minus">
        <button onClick={handleMinusClick}>-</button>
        <span>{count}</span>
        <button onClick={handlePlusClick}>+</button>
      </div>
    </div>
  );
}
