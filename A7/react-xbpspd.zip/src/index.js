import React from 'react';
import { createRoot } from 'react-dom/client';
import Art from './products.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="hdr">
      <h1>"Worthless Art"</h1>
    </div>

    <div id="body">
      <div id="title">
        <h1>My Collection</h1>
      </div>
      <div id="products">
        <Art
          src="https://www.vangoghgallery.com/img/starry_night_full.jpg"
          alt="The Starry Night"
          artist="Vincent Van Gogh"
          paintName="The Starry Night"
          p="3"
        />

        <Art
          src="https://t1.gstatic.com/licensed-image?q=tbn:ANd9GcQ-FvbbAq5IaJUhtwxXEwY0D-jiZju02ejnNHx_bQWL_27GF3srhwJgqusMAqKh3QqU"
          alt="Mona Lisa"
          artist="Leonardo da Vinci"
          paintName="Mona Lisa"
          p="12"
        />

        <Art
          src="https://lh3.googleusercontent.com/J0sw0IiqP2F4gavYnI-vUa5IBgHiHy42lohgm-qq1vuygUX0HQgylVSV1ZdDTV5XIg=s1200"
          alt="Girl with a Pearl Earring"
          artist="Johannes Vermeer"
          paintName="Girl with a Pearl Earring"
          p="17"
        />

        <Art
          src="https://lh3.googleusercontent.com/XQBr2BcJcZEPUOLp-CmzMH58BcdgPJEYm17IPbPvFvqMQ2zmDmVn7mPvqPvbg_OaYQ=s1200"
          alt="The birth of Venus"
          artist="Sandro Botticelli"
          paintName="The birth of Venus"
          p="8"
        />
      </div>
    </div>

    <div id="footer">2023 FinnWalker USA, Inc. All Rights Reserved.</div>
  </React.StrictMode>
);
