import React from 'react';
import './Comment.css';

// remember to import styling css file

// Remember to add:
/*
At least four (4) mock user comments / reviews / posts.
These can be user comments (like Youtube comments), reviews (like Amazon product review), user posts (like FB posts or Twitter tweets), etc.
Each user comment needs to have:
A profile picture, "profile-img"
Username, "username"
Date, "date"
Content (comment, review, post, etc). "cont-text"

Set it up below
PICTURE -> grab some old xbox 360 images 
USERNAME -> randomly generate
DATE -> (make small in CSS) -> random date
COMMENT -> randomly generate comment about bananas 


FOR LAB 6 (DONE BEFORE FOR A5)
Convert mock user comments / reviews / posts into a reusable component. - done
Put the component in a separate JS file. - done in Comment.js
This component needs to accept props for all the data that is displayed, including: - done --> div name = comment
Profile picture (src and alt attributes), - done (profile-img)
Username, - username
Date, - date
Content (comment, review, post, etc.), - cont-text (What the comment says)
Other data (if any). - didn't include any (Style the comments)


*/

const Comment = ({ profileImg, username, date, content }) => {
  return (
    <div className="comment">
      <img src={profileImg} alt={username} className="profile-img" />
      <div className="comment-content">
        <div className="user-info">
          <p className="username">{username}</p>
          <p className="date">{date}</p>
        </div>

        <p className="cont-text">{content}</p>
      </div>
    </div>
  );
};

export default Comment;
